"""
tests/core/test_input.py
────────────────────────────────────────────────────────────────
Commit 19: suite completa de Input (41 → 50 testes).
Todos os testes injetam estados diretamente nos atributos de classe,
evitando dependência de pygame.key.get_pressed() / pygame.mouse.*
"""
from __future__ import annotations

import pytest
import pygame


# ---------------------------------------------------------------------------
# Helper: cria um array de teclas fake
# ---------------------------------------------------------------------------

def _make_keys(*pressed_keys):
    """
    Retorna uma lista com as teclas indicadas ativas.
    Dimensiona automaticamente para acomodar scancodes altos
    (ex.: pygame.K_LEFT ≈ 1073741904).
    """
    size = max(pressed_keys, default=0) + 1
    size = max(size, 512)  # mínimo 512 para teclas comuns
    keys = [False] * size
    for k in pressed_keys:
        keys[k] = True
    return keys


# ===========================================================================
# 1. get_key
# ===========================================================================

class TestGetKey:
    def test_held_key_returns_true(self):
        from engine.input import Input
        Input._keys_current = _make_keys(pygame.K_a)
        assert Input.get_key(pygame.K_a) is True

    def test_not_held_returns_false(self):
        from engine.input import Input
        Input._keys_current = _make_keys()
        assert Input.get_key(pygame.K_a) is False

    def test_empty_state_returns_false(self):
        from engine.input import Input
        Input._keys_current = []
        assert Input.get_key(pygame.K_SPACE) is False

    def test_invalid_key_returns_false(self):
        from engine.input import Input
        Input._keys_current = _make_keys()
        assert Input.get_key(9999) is False


# ===========================================================================
# 2. get_key_down
# ===========================================================================

class TestGetKeyDown:
    def test_key_down_only_on_first_frame(self):
        from engine.input import Input
        Input._keys_previous = _make_keys()
        Input._keys_current  = _make_keys(pygame.K_a)
        assert Input.get_key_down(pygame.K_a) is True

    def test_key_down_false_when_held(self):
        from engine.input import Input
        Input._keys_previous = _make_keys(pygame.K_a)
        Input._keys_current  = _make_keys(pygame.K_a)
        assert Input.get_key_down(pygame.K_a) is False

    def test_key_down_false_when_not_pressed(self):
        from engine.input import Input
        Input._keys_previous = _make_keys()
        Input._keys_current  = _make_keys()
        assert Input.get_key_down(pygame.K_a) is False

    def test_key_down_empty_state_safe(self):
        from engine.input import Input
        Input._keys_previous = []
        Input._keys_current  = []
        assert Input.get_key_down(pygame.K_a) is False


# ===========================================================================
# 3. get_key_up
# ===========================================================================

class TestGetKeyUp:
    def test_key_up_on_release_frame(self):
        from engine.input import Input
        Input._keys_previous = _make_keys(pygame.K_SPACE)
        Input._keys_current  = _make_keys()
        assert Input.get_key_up(pygame.K_SPACE) is True

    def test_key_up_false_while_held(self):
        from engine.input import Input
        Input._keys_previous = _make_keys(pygame.K_SPACE)
        Input._keys_current  = _make_keys(pygame.K_SPACE)
        assert Input.get_key_up(pygame.K_SPACE) is False

    def test_key_up_false_when_never_pressed(self):
        from engine.input import Input
        Input._keys_previous = _make_keys()
        Input._keys_current  = _make_keys()
        assert Input.get_key_up(pygame.K_SPACE) is False


# ===========================================================================
# 4. Mouse position e rel
# ===========================================================================

class TestMousePosition:
    def test_get_mouse_position(self):
        from engine.input import Input
        Input._mouse_position = (320, 240)
        assert Input.get_mouse_position() == (320, 240)

    def test_get_mouse_rel(self):
        from engine.input import Input
        Input._mouse_rel = (5, -3)
        assert Input.get_mouse_rel() == (5, -3)


# ===========================================================================
# 5. Mouse buttons
# ===========================================================================

class TestMouseButton:
    def test_button_held_returns_true(self):
        from engine.input import Input
        Input._mouse_current = (True, False, False)
        assert Input.get_mouse_button(0) is True

    def test_button_not_held_returns_false(self):
        from engine.input import Input
        Input._mouse_current = (False, False, False)
        assert Input.get_mouse_button(0) is False

    def test_button_invalid_index_safe(self):
        from engine.input import Input
        Input._mouse_current = (False, False, False)
        assert Input.get_mouse_button(99) is False

    def test_button_down_first_frame(self):
        from engine.input import Input
        Input._mouse_previous = (False, False, False)
        Input._mouse_current  = (True,  False, False)
        assert Input.get_mouse_button_down(0) is True

    def test_button_down_false_when_held(self):
        from engine.input import Input
        Input._mouse_previous = (True, False, False)
        Input._mouse_current  = (True, False, False)
        assert Input.get_mouse_button_down(0) is False

    def test_button_up_on_release(self):
        from engine.input import Input
        Input._mouse_previous = (True,  False, False)
        Input._mouse_current  = (False, False, False)
        assert Input.get_mouse_button_up(0) is True

    def test_button_up_false_while_held(self):
        from engine.input import Input
        Input._mouse_previous = (True, False, False)
        Input._mouse_current  = (True, False, False)
        assert Input.get_mouse_button_up(0) is False

    def test_right_button(self):
        from engine.input import Input
        Input._mouse_current = (False, False, True)
        assert Input.get_mouse_button(2) is True


# ===========================================================================
# 6. Axes
# ===========================================================================

class TestAxes:
    def test_horizontal_left_arrow(self):
        from engine.input import Input
        Input._keys_current = _make_keys(pygame.K_LEFT)
        assert Input.get_axis_horizontal() == pytest.approx(-1.0)

    def test_horizontal_right_arrow(self):
        from engine.input import Input
        Input._keys_current = _make_keys(pygame.K_RIGHT)
        assert Input.get_axis_horizontal() == pytest.approx(1.0)

    def test_horizontal_a_key(self):
        from engine.input import Input
        Input._keys_current = _make_keys(pygame.K_a)
        assert Input.get_axis_horizontal() == pytest.approx(-1.0)

    def test_horizontal_d_key(self):
        from engine.input import Input
        Input._keys_current = _make_keys(pygame.K_d)
        assert Input.get_axis_horizontal() == pytest.approx(1.0)

    def test_horizontal_neutral(self):
        from engine.input import Input
        Input._keys_current = _make_keys()
        assert Input.get_axis_horizontal() == pytest.approx(0.0)

    def test_horizontal_both_cancel(self):
        from engine.input import Input
        Input._keys_current = _make_keys(pygame.K_LEFT, pygame.K_RIGHT)
        assert Input.get_axis_horizontal() == pytest.approx(0.0)

    def test_vertical_up_arrow(self):
        from engine.input import Input
        Input._keys_current = _make_keys(pygame.K_UP)
        assert Input.get_axis_vertical() == pytest.approx(-1.0)

    def test_vertical_down_arrow(self):
        from engine.input import Input
        Input._keys_current = _make_keys(pygame.K_DOWN)
        assert Input.get_axis_vertical() == pytest.approx(1.0)

    def test_vertical_w_key(self):
        from engine.input import Input
        Input._keys_current = _make_keys(pygame.K_w)
        assert Input.get_axis_vertical() == pytest.approx(-1.0)

    def test_vertical_s_key(self):
        from engine.input import Input
        Input._keys_current = _make_keys(pygame.K_s)
        assert Input.get_axis_vertical() == pytest.approx(1.0)

    def test_vertical_neutral(self):
        from engine.input import Input
        Input._keys_current = _make_keys()
        assert Input.get_axis_vertical() == pytest.approx(0.0)

    def test_vertical_both_cancel(self):
        from engine.input import Input
        Input._keys_current = _make_keys(pygame.K_UP, pygame.K_DOWN)
        assert Input.get_axis_vertical() == pytest.approx(0.0)


# ===========================================================================
# 7. update() rotaciona os estados
# ===========================================================================

class TestUpdate:
    def test_update_rotates_key_state(self):
        from engine.input import Input
        from unittest.mock import patch
        new_keys = _make_keys(pygame.K_SPACE)
        with patch("engine.input.pygame.key.get_pressed", return_value=new_keys), \
             patch("engine.input.pygame.mouse.get_pressed", return_value=(False,False,False)), \
             patch("engine.input.pygame.mouse.get_pos", return_value=(0,0)), \
             patch("engine.input.pygame.mouse.get_rel", return_value=(0,0)):
            old_current = Input._keys_current
            Input.update()
            assert Input._keys_previous is old_current

    def test_update_sets_new_current(self):
        from engine.input import Input
        from unittest.mock import patch
        new_keys = _make_keys(pygame.K_RETURN)
        with patch("engine.input.pygame.key.get_pressed", return_value=new_keys), \
             patch("engine.input.pygame.mouse.get_pressed", return_value=(False,False,False)), \
             patch("engine.input.pygame.mouse.get_pos", return_value=(100,200)), \
             patch("engine.input.pygame.mouse.get_rel", return_value=(1,2)):
            Input.update()
            assert Input._keys_current is new_keys
            assert Input._mouse_position == (100, 200)


# ===========================================================================
# 8. Edge cases
# ===========================================================================

class TestInputEdgeCases:
    def test_any_key_pressed_true_when_key_held(self):
        """any_key (se existir) retorna True quando alguma tecla está pressionada."""
        from engine.input import Input
        Input._keys_current = _make_keys(pygame.K_z)
        # Testa get_key com tecla diferente de K_z para garantir isolamento
        assert Input.get_key(pygame.K_z) is True
        assert Input.get_key(pygame.K_a) is False

    def test_key_down_and_key_not_interfere(self):
        """get_key_down em K_b não afeta get_key em K_a."""
        from engine.input import Input
        Input._keys_previous = _make_keys()
        Input._keys_current  = _make_keys(pygame.K_b)
        assert Input.get_key_down(pygame.K_b) is True
        assert Input.get_key_down(pygame.K_a) is False

    def test_mouse_position_tuple_type(self):
        from engine.input import Input
        Input._mouse_position = (0, 0)
        pos = Input.get_mouse_position()
        assert isinstance(pos, tuple) and len(pos) == 2

    def test_mouse_rel_negative_values(self):
        """Movimento para cima/esquerda retorna valores negativos."""
        from engine.input import Input
        Input._mouse_rel = (-10, -20)
        assert Input.get_mouse_rel() == (-10, -20)

    def test_middle_mouse_button(self):
        from engine.input import Input
        Input._mouse_current = (False, True, False)
        assert Input.get_mouse_button(1) is True
        assert Input.get_mouse_button(0) is False

    def test_button_down_right_button(self):
        from engine.input import Input
        Input._mouse_previous = (False, False, False)
        Input._mouse_current  = (False, False, True)
        assert Input.get_mouse_button_down(2) is True

    def test_button_up_middle_button(self):
        from engine.input import Input
        Input._mouse_previous = (False, True, False)
        Input._mouse_current  = (False, False, False)
        assert Input.get_mouse_button_up(1) is True

    def test_diagonal_movement_axes(self):
        """Pressionar UP e RIGHT simultaneamente resulta em (-1, 1) nos eixos."""
        from engine.input import Input
        Input._keys_current = _make_keys(pygame.K_UP, pygame.K_RIGHT)
        assert Input.get_axis_vertical()   == pytest.approx(-1.0)
        assert Input.get_axis_horizontal() == pytest.approx(1.0)

    def test_key_held_multiple_frames_still_true(self):
        """get_key continua True frame após frame enquanto pressionado."""
        from engine.input import Input
        Input._keys_current = _make_keys(pygame.K_LSHIFT)
        for _ in range(5):
            assert Input.get_key(pygame.K_LSHIFT) is True
