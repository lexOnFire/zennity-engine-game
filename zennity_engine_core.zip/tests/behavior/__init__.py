"""Testes do Behavior Controller."""
